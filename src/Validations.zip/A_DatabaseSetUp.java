import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class A_DatabaseSetUp 
{
    static String strDriver = "com.mysql.jdbc.Driver";
    static String strConn = "jdbc:mysql://localhost:3306/";
    static String strUser = "root";
    static String strPass = "";
    
    static Connection objConn;
    static String strTable, strDb, strInput;
    
    public static void main(String[] args)
    {
    	CreateDB();
    	CreateTables();
    }
    
    public static void CreateDB()
    {
        try 
        {
            Class.forName(strDriver);
        	
        	Scanner objDataEntry = new Scanner(System.in);
        	
        	System.out.print("Enter the root password: ");
        	strPass = objDataEntry.next();
        	
        	objConn = DriverManager.getConnection(strConn, strUser, strPass);
        	System.out.print("Login successful...\n\n");
        	
        	Statement objCreateDB = objConn.createStatement();
        	
        	String strCreateDB = "CREATE DATABASE OrderForm;";
        	objCreateDB.executeUpdate(strCreateDB);
        	
        	System.out.print("Database 'OrderForm' has been created...");   
        	
        	objDataEntry.close();
        } 
        
        catch (Exception objEx) 
        {
            System.out.println("Login failed!");
            System.out.println(objEx.toString());
        } 
        
        finally 
        { 
            strConn = "jdbc:mysql://localhost:3306/OrderForm";
        }
     }
        
     public static void CreateTables()
     {
    	 try 
         {  		
    		 objConn = DriverManager.getConnection(strConn, strUser, strPass);
	            	            
	         String strSQLCreateTable1 = "CREATE TABLE TblOrder (" + 
	                                     "OrderID CHAR(10) NOT NULL, OrderDesc CHAR(15) NOT NULL, OrderPrice DECIMAL(18,2) NOT NULL, "
	                                     + "PRIMARY KEY (OrderID))";
	            
	         String strSQLCreateTable2 = "CREATE TABLE TblClient (" + 
					                     "ClientNum CHAR(5) NOT NULL, ClientName CHAR(50) NOT NULL, ClientContact CHAR(11) NOT NULL, ClientEmail CHAR(30) NOT NULL, " + 
					                     "PaymentRefNumber CHAR(15) NOT NULL, PaymentMode CHAR(10) NOT NULL,"
					                     + "PRIMARY KEY (ClientNum))";
	            
	         String strSQLCreateTable3 = "CREATE TABLE TblTransaction (" + 
	            						 "TransactionNum CHAR(10) NOT NULL, TransactionDate DATE NOT NULL, ClientNum CHAR(5) NOT NULL, "
	            						 + "PRIMARY KEY (TransactionNum), Constraint FK FOREIGN KEY (ClientNum) REFERENCES TblClient(ClientNum))";
	            
	         String strSQLCreateTable4 = "CREATE TABLE TblCharacteristics (" + 
						            	 "TransactionNum CHAR(10) NOT NULL, OrderID CHAR(10) NOT NULL, OrderContent CHAR(255) NOT NULL, " + 
					                     "OrderSize CHAR(10) NOT NULL, OrderQty INT(2) NOT NULL, OrderTotal DECIMAL(18,2) NOT NULL, GrandTotal DECIMAL(18,2) NOT NULL,"
					                     + "Constraint FK1 FOREIGN KEY (TransactionNum) REFERENCES TblTransaction(TransactionNum),"
					                     + "Constraint FK2 FOREIGN KEY (OrderID) REFERENCES TblOrder(OrderID))";
	            
	         Statement objCreateTable = objConn.createStatement();
	            
	         objCreateTable.executeUpdate(strSQLCreateTable1);
	         objCreateTable.executeUpdate(strSQLCreateTable2);
	         objCreateTable.executeUpdate(strSQLCreateTable3);
	         objCreateTable.executeUpdate(strSQLCreateTable4);
	            
	         String strInsertTblOrder = "INSERT INTO TblOrder (OrderID, OrderDesc, OrderPrice) VALUES "
	            						+ "('GD-001', 'Logo', 500.00), "
	            						+ "('GD-002', 'Product Ads', 150.00), "
	            						+ "('GD-003', 'Shop Template', 150.00), "
	            						+ "('GD-004', 'Product Label', 150.00), "
	            						+ "('GD-005', 'Card Layout', 200.00), "
	            						+ "('GD-006', 'Cover Photo', 500.00)";
	            
	         objCreateTable.executeUpdate(strInsertTblOrder);
	            
	         System.out.println("\nDatabase tables complete...");
          } 
        
          catch (Exception objEx)
	      {
        	  System.out.println("Database tables failed!");
	          System.out.println(objEx.toString());
	      }
      }
}